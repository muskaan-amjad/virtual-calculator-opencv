import numpy as np
import cv2

class Button:
    def __init__(self, pos, width, height, value):
        self.pos = pos
        self.width = width
        self.height = height
        self.value = value

    def draw(self, img):
        x, y = self.pos
        cv2.rectangle(img, (x, y), (x + self.width, y + self.height),
                      (200, 200, 200), cv2.FILLED)
        cv2.rectangle(img, (x, y), (x + self.width, y + self.height),
                      (50, 50, 50), 2)
        font_scale = self.width / 200
        cv2.putText(img, self.value, (x + 20, y + self.height - 20),
                    cv2.FONT_HERSHEY_PLAIN, font_scale * 2, (50, 50, 50), 2)

    def checkClick(self, x, y):
        bx, by = self.pos
        return bx < x < bx + self.width and by < y < by + self.height
