import cv2
import numpy as np
import math
from hand_tracking import HandDetector
from calculator import Button

cap = cv2.VideoCapture(0)
cap.set(3, 1280)
cap.set(4, 720)

detector = HandDetector(detectionCon=0.8)

btns = []
btn_layout = [['7','8','9','/'],
              ['4','5','6','*'],
              ['1','2','3','-'],
              ['C','0','=','+']]
for i, row in enumerate(btn_layout):
    for j, val in enumerate(row):
        btns.append(Button((100*j + 50, 100*i + 50), 100, 100, val))

expr = ''
delay_counter = 0

while True:
    success, img = cap.read()
    if not success:
        break
    img = cv2.flip(img, 1)

    img = detector.findHands(img)
    lmList = detector.findPosition(img)

    for btn in btns:
        btn.draw(img)

    if lmList:
        x1, y1 = lmList[8][1], lmList[8][2]
        x2, y2 = lmList[12][1], lmList[12][2]
        cv2.circle(img, (x1, y1), 10, (255, 0, 255), cv2.FILLED)

        if delay_counter == 0:
            for btn in btns:
                if btn.checkClick(x1, y1):
                    length = math.hypot(x2 - x1, y2 - y1)
                    if length < 40:
                        if btn.value == '=':
                            try:
                                expr = str(eval(expr))
                            except:
                                expr = 'Err'
                        elif btn.value == 'C':
                            expr = ''
                        else:
                            expr += btn.value
                        delay_counter = 10

    if delay_counter > 0:
        delay_counter -= 1

    cv2.rectangle(img, (50, 520), (450, 620), (255, 255, 255), cv2.FILLED)
    cv2.putText(img, expr, (60, 600),
                cv2.FONT_HERSHEY_PLAIN, 4, (0, 0, 0), 4)

    cv2.imshow("Virtual Calculator", img)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
